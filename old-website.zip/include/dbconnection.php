<?php
$con=mysqli_connect("localhost", "horizonf_runwal", "runwal@123", "horizonf_runwalnew");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
