<?php
include('include/vid.php');
$wid=98;
 ?>
 
 <?php
        if(array_key_exists('enq_formBtn', $_POST)) {
   
            $a = "India+91";


    if (cf_888 == $a) 
        {
        $uid = '98';
         } 
  
  else 
    {
    $uid = '183';
     }
    return  $uid;
        }
        
    ?>