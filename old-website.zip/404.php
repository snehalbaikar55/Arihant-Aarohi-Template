<html>
<title>404 Not Found</title>
<!--****************** BODY SECTION STARTS ******************-->
<body>
    
<!-- 404 page data --> 
<section  style="top:50px;">
<span class="section-link">
</span>
<div class="container" style="text-align: center;">
		<div class="col-md-10">
			<h1>ERROR 404!</h1>
			 <h3>SORRY, PAGE NOT FOUND!</h3>
			 <p>We can't seem to find the page you're looking for. You may have mistyped or misspelled the URL.<br>
It could also mean that the URL does not exist, or maybe it was moved!</p>
		</div>
		
	</div>
</section> 

    
</body>
</html>